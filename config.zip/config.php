<?php
include_once('mydql2i/mysql2i.class.php');
date_default_timezone_set("Asia/Kolkata"); 
ob_start();
session_start();
error_reporting(0);
############################
### For Page Redirection ###
############################

//$http = 'http://';
//$preUrl = $_SERVER['HTTP_HOST'];
//$directoryUrl = '/dairyLac';
//$editpath = $preUrl.$directoryUrl;
//$absolutePath = $http.$preUrl.$directoryUrl;
//$absolutePath = $http.$preUrl;
//$absolutePath1 = $preUrl;

/*if (!(isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] == 'on' || 
   $_SERVER['HTTPS'] == 1) ||  
   isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&   
   $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https'))
{
   $redirect = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
   header('HTTP/1.1 301 Moved Permanently');
   header('Location: ' . $redirect);
   exit();
}*/

$http = 'http://';
$preUrl = $_SERVER['HTTP_HOST'];
if($_SERVER['HTTP_HOST']=='111.93.38.231:8081')
{
	$preUrl = '111.93.38.231:8081';
}else
{
	$preUrl = '172.20.10.174';
}

$directoryUrl = '/dairyLac';
$editpath = $preUrl.$directoryUrl;
$absolutePath = $http.$preUrl.$directoryUrl;
$absolutePath1 = $preUrl;



$sessionid = session_id();
global $sessionid;

	/* Live */
    $dbhost = "localhost";
	$dbuser = "root";
	$dbpass = "ehs@#$987";
	$dbname = "dairy_bank";
	
	/* UAT 
	$dbhost = 'localhost';
	$dbuser = 'root';
	$dbpass = 'ehs@#$987';
	$dbname = 'dairy_bank';*/
	
	$link1 = mysql_connect($dbhost,$dbuser,$dbpass) or mysql_error("Not able to connect with MySql Server");
	$link = mysql_select_db($dbname,$link1) or mysql_error("Not able to connect with Database");

function SMS_send($mobile,$m_msg,$tid)
{
	if($_SERVER['HTTP_HOST']=='manage.dairylac.com')
	{
		$token="af979794dbfdf67595fe8b1ac0c59017";
		//$tid="1607100000000103505";
		$url = "http://sms.paragalaxy.com/smpp_api/sms";
		$data = array(
				"token" => $token,
				"tid" => $tid,
				"To" => $mobile,
				"Text" => $m_msg
				);
		$query_url = sprintf("%s?%s", $url, http_build_query($data));
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_URL, $query_url);
		curl_setopt($ch, CURLOPT_TIMEOUT, 80);
		$response = curl_exec($ch);
		if(curl_error($ch)){
			return 'Request Error:' . curl_error($ch);
		}
		else
		{
			return $response;
		}
			curl_close($ch);
		//return $result;
	}
}	
?>
